export default function About() {
    return (
        <h2>About</h2>
    )
}