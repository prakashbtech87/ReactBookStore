import React from "react";
import NavBar from "./partials/NavBar";
import { Outlet } from "react-router-dom";
import CreateBook from "./CreateBook";

export default function Layout() {
    return (
        <React.Fragment>
            <NavBar />
            <Outlet />
        </React.Fragment>
    );
}